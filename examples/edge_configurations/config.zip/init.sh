#!/bin/sh\necho Hello from Edge config
